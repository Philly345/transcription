# TranscribeAI - AI-Powered Transcription Web Application

A complete, production-ready transcription web application built with Next.js, React, and Tailwind CSS. Features AI-powered transcription with advanced processing capabilities including speaker identification, timestamps, and intelligent summaries.

## 🚀 Features

### Frontend
- **Modern Landing Page** with animated elements and Spotify-style floating bubbles
- **Complete Authentication Flow** (signup, login, forgot/reset password)
- **ChatGPT-style Dashboard** with sidebar navigation
- **Drag & Drop File Upload** with real-time progress tracking
- **Responsive Design** with dark mode support
- **Advanced Settings Panel** for transcription customization

### Backend
- **AI-Powered Transcription** using OpenAI Whisper via AI SDK
- **Intelligent Processing** with GPT-4 for summaries and topic detection
- **Multi-format Support** (MP3, WAV, MP4, MOV, etc.)
- **Speaker Identification** for up to 10 speakers
- **Timestamp Generation** with word-level precision
- **Profanity Filtering** and auto-punctuation

### Technical Features
- **JWT Authentication** with secure token handling
- **File Processing** with progress tracking
- **Storage Management** with usage monitoring
- **Real-time Updates** for processing status
- **Error Handling** with user-friendly messages

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: Tailwind CSS with custom animations
- **UI Components**: Radix UI primitives
- **AI Integration**: AI SDK with OpenAI models
- **Authentication**: JWT with bcrypt password hashing
- **File Handling**: React Dropzone with FormData
- **Deployment**: Vercel-optimized serverless functions

## 📦 Installation

1. **Clone the repository**
\`\`\`bash
git clone <repository-url>
cd transcribe-ai
\`\`\`

2. **Install dependencies**
\`\`\`bash
npm install
\`\`\`

3. **Set up environment variables**
\`\`\`bash
cp .env.local.example .env.local
\`\`\`

Edit `.env.local` and add your API keys:
\`\`\`env
OPENAI_API_KEY=your_openai_api_key_here
JWT_SECRET=your_jwt_secret_here
\`\`\`

4. **Run the development server**
\`\`\`bash
npm run dev
\`\`\`

5. **Open your browser**
Navigate to `http://localhost:3000`

## 🔑 API Keys Required

### OpenAI API Key
1. Go to [OpenAI Platform](https://platform.openai.com)
2. Create an account or sign in
3. Navigate to API Keys section
4. Create a new API key
5. Add to `.env.local` as `OPENAI_API_KEY`

### Optional: Additional Transcription Services
- **AssemblyAI**: For alternative transcription service
- **Deepgram**: For real-time transcription capabilities

## 🚀 Deployment

### Deploy to Vercel (Recommended)

1. **Push to GitHub**
\`\`\`bash
git add .
git commit -m "Initial commit"
git push origin main
\`\`\`

2. **Deploy to Vercel**
- Go to [Vercel Dashboard](https://vercel.com)
- Import your GitHub repository
- Add environment variables in Vercel dashboard
- Deploy automatically

3. **Configure Environment Variables in Vercel**
- `OPENAI_API_KEY`
- `JWT_SECRET`
- Any additional API keys

### Manual Deployment

\`\`\`bash
npm run build
npm start
\`\`\`

## 📁 Project Structure

\`\`\`
transcribe-ai/
├── app/
│   ├── api/                 # Serverless API routes
│   │   ├── auth/           # Authentication endpoints
│   │   ├── transcribe/     # Transcription processing
│   │   └── dashboard/      # Dashboard data
│   ├── dashboard/          # Dashboard pages
│   ├── upload/            # File upload page
│   ├── login/             # Authentication pages
│   └── globals.css        # Global styles
├── components/
│   ├── ui/                # Reusable UI components
│   ├── auth-provider.tsx  # Authentication context
│   └── dashboard-layout.tsx # Dashboard layout
├── lib/
│   └── utils.ts           # Utility functions
└── public/                # Static assets
\`\`\`

## 🎨 Customization

### Styling
- Modify `app/globals.css` for global styles
- Update Tailwind config in `tailwind.config.ts`
- Customize animations and effects

### AI Models
- Change transcription model in `/api/transcribe/route.ts`
- Adjust AI processing prompts for summaries
- Add new AI capabilities

### Authentication
- Integrate with Supabase, Firebase, or other auth providers
- Add OAuth providers (Google, GitHub, etc.)
- Implement role-based access control

## 🔧 Configuration

### Supported File Formats
- **Audio**: MP3, WAV, M4A, FLAC, AAC
- **Video**: MP4, MOV, AVI, MKV, WMV
- **Limits**: 500MB max file size, 4 hours duration

### Transcription Settings
- **Languages**: 50+ supported languages
- **Quality**: Standard and High options
- **Features**: Speaker ID, timestamps, profanity filter
- **Processing**: 2-5 minutes per hour of audio

## 🐛 Troubleshooting

### Common Issues

1. **API Key Errors**
   - Verify OpenAI API key is correct
   - Check API key has sufficient credits
   - Ensure environment variables are set

2. **File Upload Issues**
   - Check file size limits (500MB max)
   - Verify supported file formats
   - Ensure stable internet connection

3. **Authentication Problems**
   - Clear browser localStorage
   - Check JWT_SECRET is set
   - Verify API endpoints are accessible

### Debug Mode
Enable debug logging by adding to `.env.local`:
\`\`\`env
NODE_ENV=development
DEBUG=true
\`\`\`

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue on GitHub
- Check the documentation
- Review the troubleshooting guide

## 🔮 Future Enhancements

- [ ] Real-time transcription
- [ ] Batch processing
- [ ] API access for developers
- [ ] Advanced analytics
- [ ] Team collaboration features
- [ ] Custom vocabulary training
- [ ] Integration with cloud storage
- [ ] Mobile app companion

---

Built with ❤️ using Next.js, AI SDK, and modern web technologies.
