'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Mic, Zap, Shield, Clock, Star, ChevronDown, FileAudio, Users, Globe } from 'lucide-react'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

export default function HomePage() {
  const [typingText, setTypingText] = useState('')
  const fullText = 'Transform audio into accurate text with AI precision'

  useEffect(() => {
    let i = 0
    const timer = setInterval(() => {
      if (i < fullText.length) {
        setTypingText(fullText.slice(0, i + 1))
        i++
      } else {
        clearInterval(timer)
      }
    }, 50)

    return () => clearInterval(timer)
  }, [])

  const features = [
    {
      icon: <Mic className="h-8 w-8" />,
      title: 'AI-Powered Transcription',
      description: 'Advanced speech recognition with 99%+ accuracy'
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: 'Lightning Fast',
      description: 'Process hours of audio in minutes'
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: 'Secure & Private',
      description: 'Your data is encrypted and never stored permanently'
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: 'Speaker Identification',
      description: 'Automatically identify and separate different speakers'
    },
    {
      icon: <Clock className="h-8 w-8" />,
      title: 'Timestamps',
      description: 'Precise timing for every word and sentence'
    },
    {
      icon: <Globe className="h-8 w-8" />,
      title: 'Multi-Language',
      description: 'Support for 50+ languages and dialects'
    }
  ]

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Journalist',
      content: 'TranscribeAI has revolutionized my workflow. What used to take hours now takes minutes.',
      rating: 5
    },
    {
      name: 'Dr. Michael Chen',
      role: 'Researcher',
      content: 'The accuracy is incredible. Perfect for transcribing interviews and lectures.',
      rating: 5
    },
    {
      name: 'Emma Rodriguez',
      role: 'Content Creator',
      content: 'Speaker identification feature is a game-changer for my podcast transcriptions.',
      rating: 5
    }
  ]

  const faqs = [
    {
      question: 'What file formats do you support?',
      answer: 'We support all major audio and video formats including MP3, WAV, MP4, MOV, and many more. Files up to 500MB and 4 hours in length.'
    },
    {
      question: 'How accurate is the transcription?',
      answer: 'Our AI achieves 99%+ accuracy on clear audio. Accuracy may vary based on audio quality, background noise, and speaker clarity.'
    },
    {
      question: 'Is my data secure?',
      answer: 'Absolutely. All files are encrypted during upload and processing. We delete your files after transcription unless you choose to save them.'
    },
    {
      question: 'How long does transcription take?',
      answer: 'Typically 2-5 minutes per hour of audio, depending on file size and complexity. You\'ll receive real-time progress updates.'
    },
    {
      question: 'Do you offer speaker identification?',
      answer: 'Yes! Our AI can identify and separate up to 10 different speakers in your audio, making it perfect for meetings and interviews.'
    }
  ]

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Floating Bubbles Background */}
      <div className="floating-bubbles">
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-10 flex items-center justify-between p-6 max-w-7xl mx-auto">
        <div className="flex items-center space-x-2">
          <FileAudio className="h-8 w-8 text-primary" />
          <span className="text-2xl font-bold gradient-logo">TranscribeAI</span>
        </div>
        <div className="flex items-center space-x-4">
          <Link href="/upload">
            <Button variant="ghost">Try Demo</Button>
          </Link>
          <Link href="/upload">
            <Button className="glow-button">Get Started</Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 text-center py-20 px-6 max-w-4xl mx-auto">
        <Badge variant="secondary" className="mb-6">
          🚀 Now with AI-powered summaries
        </Badge>
        
        <h1 className="text-6xl md:text-7xl font-bold mb-6 gradient-logo">
          Transcribe smarter, not harder.
        </h1>
        
        <div className="text-xl md:text-2xl text-muted-foreground mb-8 h-8">
          <span className="typing-animation">{typingText}</span>
        </div>
        
        <Link href="/upload">
          <Button size="lg" className="glow-button text-lg px-8 py-4">
            Transcribe Now
          </Button>
        </Link>
        
        <p className="text-sm text-muted-foreground mt-4">
          No account required • Start transcribing instantly
        </p>
      </section>

      {/* Features Section */}
      <section className="relative z-10 py-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Powerful Features</h2>
          <p className="text-xl text-muted-foreground">
            Everything you need for professional transcription
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-border/50 hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="text-primary mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="relative z-10 py-20 px-6 bg-muted/20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-xl text-muted-foreground">
              Trusted by professionals worldwide
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-border/50 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="relative z-10 py-20 px-6 max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about TranscribeAI
          </p>
        </div>
        
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50 py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <FileAudio className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">TranscribeAI</span>
            </div>
            <div className="flex space-x-6 text-sm text-muted-foreground">
              <Link href="/privacy" className="hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="hover:text-foreground transition-colors">
                Terms of Service
              </Link>
              <Link href="/contact" className="hover:text-foreground transition-colors">
                Contact
              </Link>
            </div>
          </div>
          <div className="text-center text-sm text-muted-foreground mt-8">
            © 2024 TranscribeAI. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
