'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { useDropzone } from 'react-dropzone'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Upload, FileAudio, FileVideo, X, Info, Settings, Clock, Users, Globe, Filter } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { useAuth } from '@/components/auth-provider'

interface UploadFile {
  file: File
  preview: string
  progress: number
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'error'
}

interface TranscriptionSettings {
  language: string
  quality: 'standard' | 'high'
  speakerIdentification: boolean
  includeTimestamps: boolean
  filterProfanity: boolean
  autoPunctuation: boolean
}

export default function UploadPage() {
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([])
  const [settings, setSettings] = useState<TranscriptionSettings>({
    language: 'en',
    quality: 'standard',
    speakerIdentification: false,
    includeTimestamps: true,
    filterProfanity: false,
    autoPunctuation: true
  })
  const [isUploading, setIsUploading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()

  const acceptedFormats = {
    'audio/*': ['.mp3', '.wav', '.m4a', '.flac', '.aac'],
    'video/*': ['.mp4', '.mov', '.avi', '.mkv', '.wmv']
  }

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      preview: URL.createObjectURL(file),
      progress: 0,
      status: 'pending' as const
    }))
    
    setUploadFiles(prev => [...prev, ...newFiles])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: acceptedFormats,
    maxSize: 500 * 1024 * 1024, // 500MB
    multiple: true
  })

  const removeFile = (index: number) => {
    setUploadFiles(prev => {
      const newFiles = [...prev]
      URL.revokeObjectURL(newFiles[index].preview)
      newFiles.splice(index, 1)
      return newFiles
    })
  }

  const estimateProcessingTime = (files: UploadFile[]) => {
    // Rough estimate: 2-5 minutes per hour of audio
    const totalSizeGB = files.reduce((acc, f) => acc + f.file.size, 0) / (1024 * 1024 * 1024)
    const estimatedHours = totalSizeGB * 0.5 // Rough conversion
    const processingMinutes = estimatedHours * 3.5 // Average of 2-5 minutes
    return Math.max(1, Math.round(processingMinutes))
  }

  const handleUpload = async () => {
    if (uploadFiles.length === 0) return

    setIsUploading(true)

    try {
      for (let i = 0; i < uploadFiles.length; i++) {
        const fileData = uploadFiles[i]
        
        // Update status to uploading
        setUploadFiles(prev => {
          const updated = [...prev]
          updated[i].status = 'uploading'
          return updated
        })

        const formData = new FormData()
        formData.append('file', fileData.file)
        formData.append('settings', JSON.stringify(settings))

        // Simulate upload progress
        const progressInterval = setInterval(() => {
          setUploadFiles(prev => {
            const updated = [...prev]
            if (updated[i].progress < 90) {
              updated[i].progress += Math.random() * 10
            }
            return updated
          })
        }, 200)

        const response = await fetch('/api/transcribe', {
          method: 'POST',
          body: formData
        })

        clearInterval(progressInterval)

        if (response.ok) {
          const result = await response.json()
          
          setUploadFiles(prev => {
            const updated = [...prev]
            updated[i].progress = 100
            updated[i].status = 'processing'
            return updated
          })

          toast({
            title: 'Upload Successful',
            description: `${fileData.file.name} is now being processed`
          })
        } else {
          setUploadFiles(prev => {
            const updated = [...prev]
            updated[i].status = 'error'
            return updated
          })

          toast({
            title: 'Upload Failed',
            description: `Failed to upload ${fileData.file.name}`,
            variant: 'destructive'
          })
        }
      }

      // Redirect to dashboard after all uploads
      setTimeout(() => {
        router.push('/dashboard')
      }, 2000)

    } catch (error) {
      toast({
        title: 'Error',
        description: 'Something went wrong during upload',
        variant: 'destructive'
      })
    } finally {
      setIsUploading(false)
    }
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('audio/')) {
      return <FileAudio className="h-8 w-8 text-blue-500" />
    } else if (file.type.startsWith('video/')) {
      return <FileVideo className="h-8 w-8 text-purple-500" />
    }
    return <FileAudio className="h-8 w-8 text-gray-500" />
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline">Ready</Badge>
      case 'uploading':
        return <Badge variant="secondary" className="text-blue-600 bg-blue-100 dark:bg-blue-900">Uploading</Badge>
      case 'processing':
        return <Badge variant="secondary" className="text-yellow-600 bg-yellow-100 dark:bg-yellow-900">Processing</Badge>
      case 'completed':
        return <Badge variant="secondary" className="text-green-600 bg-green-100 dark:bg-green-900">Completed</Badge>
      case 'error':
        return <Badge variant="destructive">Error</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Upload Files</h1>
          <p className="text-muted-foreground mt-2">
            Upload your audio or video files for AI-powered transcription
          </p>
        </div>
        
        {!user && (
          <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Info className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium text-blue-900 dark:text-blue-100">Demo Mode</p>
                  <p className="text-sm text-blue-700 dark:text-blue-200">
                    You're trying TranscribeAI without an account. Files will be processed but not saved permanently.
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={() => router.push('/signup')}>
                  Create Account
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Info className="h-4 w-4 mr-2" />
              Supported Formats
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Supported File Formats</DialogTitle>
              <DialogDescription>
                File requirements and tips for better transcription results
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold mb-3">Audio Formats</h3>
                <div className="grid grid-cols-2 gap-2">
                  {['MP3', 'WAV', 'M4A', 'FLAC', 'AAC'].map(format => (
                    <Badge key={format} variant="secondary">{format}</Badge>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-3">Video Formats</h3>
                <div className="grid grid-cols-2 gap-2">
                  {['MP4', 'MOV', 'AVI', 'MKV', 'WMV'].map(format => (
                    <Badge key={format} variant="secondary">{format}</Badge>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-3">File Requirements</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Maximum file size: 500MB</li>
                  <li>• Maximum duration: 4 hours</li>
                  <li>• Minimum sample rate: 16kHz</li>
                  <li>• Maximum speakers: 10</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold mb-3">Tips for Better Results</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Use clear audio with minimal background noise</li>
                  <li>• Avoid overlapping speech</li>
                  <li>• Keep speakers close to the microphone</li>
                  <li>• Record in a quiet environment</li>
                </ul>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Upload Area */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Upload Files</CardTitle>
              <CardDescription>
                Drag and drop your files or click to browse
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                  isDragActive 
                    ? 'border-primary bg-primary/5' 
                    : 'border-border hover:border-primary/50'
                }`}
              >
                <input {...getInputProps()} />
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                {isDragActive ? (
                  <p className="text-lg">Drop the files here...</p>
                ) : (
                  <div>
                    <p className="text-lg mb-2">Drag & drop files here, or click to select</p>
                    <p className="text-sm text-muted-foreground">
                      Supports audio and video files up to 500MB
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* File List */}
          {uploadFiles.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Selected Files</CardTitle>
                <CardDescription>
                  {uploadFiles.length} file{uploadFiles.length !== 1 ? 's' : ''} ready for processing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {uploadFiles.map((fileData, index) => (
                    <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg">
                      {getFileIcon(fileData.file)}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{fileData.file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatFileSize(fileData.file.size)}
                        </p>
                        {fileData.status === 'uploading' && (
                          <Progress value={fileData.progress} className="mt-2 h-1" />
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(fileData.status)}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFile(index)}
                          disabled={fileData.status === 'uploading' || fileData.status === 'processing'}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Settings Panel */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                Transcription Settings
              </CardTitle>
              <CardDescription>
                Configure your transcription preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="language" className="flex items-center">
                  <Globe className="h-4 w-4 mr-2" />
                  Language
                </Label>
                <Select value={settings.language} onValueChange={(value) => setSettings({...settings, language: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                    <SelectItem value="de">German</SelectItem>
                    <SelectItem value="it">Italian</SelectItem>
                    <SelectItem value="pt">Portuguese</SelectItem>
                    <SelectItem value="ru">Russian</SelectItem>
                    <SelectItem value="ja">Japanese</SelectItem>
                    <SelectItem value="ko">Korean</SelectItem>
                    <SelectItem value="zh">Chinese</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Quality</Label>
                <Select value={settings.quality} onValueChange={(value: 'standard' | 'high') => setSettings({...settings, quality: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label>Additional Options</Label>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="speakerIdentification"
                    checked={settings.speakerIdentification}
                    onCheckedChange={(checked) => setSettings({...settings, speakerIdentification: !!checked})}
                  />
                  <Label htmlFor="speakerIdentification" className="flex items-center text-sm">
                    <Users className="h-4 w-4 mr-2" />
                    Speaker Identification
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includeTimestamps"
                    checked={settings.includeTimestamps}
                    onCheckedChange={(checked) => setSettings({...settings, includeTimestamps: !!checked})}
                  />
                  <Label htmlFor="includeTimestamps" className="flex items-center text-sm">
                    <Clock className="h-4 w-4 mr-2" />
                    Include Timestamps
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="filterProfanity"
                    checked={settings.filterProfanity}
                    onCheckedChange={(checked) => setSettings({...settings, filterProfanity: !!checked})}
                  />
                  <Label htmlFor="filterProfanity" className="flex items-center text-sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter Profanity
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="autoPunctuation"
                    checked={settings.autoPunctuation}
                    onCheckedChange={(checked) => setSettings({...settings, autoPunctuation: !!checked})}
                  />
                  <Label htmlFor="autoPunctuation" className="text-sm">
                    Auto-punctuation
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Processing Time Estimate */}
          {uploadFiles.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Processing Estimate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">
                    ~{estimateProcessingTime(uploadFiles)} min
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Estimated processing time
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    2–5 minutes per hour of audio
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upload Button */}
          <Button
            onClick={handleUpload}
            disabled={uploadFiles.length === 0 || isUploading}
            className="w-full glow-button"
            size="lg"
          >
            {isUploading ? 'Processing...' : `Start Transcription (${uploadFiles.length})`}
          </Button>
        </div>
      </div>
    </div>
  )
}
