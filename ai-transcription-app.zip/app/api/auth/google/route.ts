import { NextRequest, NextResponse } from 'next/server'

// Mock Google OAuth - in production, use proper OAuth flow
export async function GET(request: NextRequest) {
  try {
    // In a real implementation, you would:
    // 1. Redirect to Google OAuth
    // 2. Handle the callback
    // 3. Exchange code for tokens
    // 4. Get user info from Google
    // 5. Create or update user in database

    // For demo purposes, create a mock Google user
    const mockGoogleUser = {
      id: 'google_' + Date.now(),
      name: 'Google User',
      email: 'googleuser@gmail.com',
      provider: 'google',
      createdAt: new Date().toISOString()
    }

    // Create a simple token (in production, use proper JWT signing on server)
    const tokenData = {
      userId: mockGoogleUser.id,
      email: mockGoogleUser.email,
      exp: Date.now() + (7 * 24 * 60 * 60 * 1000) // 7 days
    }

    const token = Buffer.from(JSON.stringify(tokenData)).toString('base64')

    // Create response that redirects to dashboard with auth data
    const dashboardUrl = new URL('/dashboard', request.url)
    dashboardUrl.searchParams.set('auth', 'success')
    dashboardUrl.searchParams.set('token', token)
    dashboardUrl.searchParams.set('user', Buffer.from(JSON.stringify({
      id: mockGoogleUser.id,
      name: mockGoogleUser.name,
      email: mockGoogleUser.email
    })).toString('base64'))

    return NextResponse.redirect(dashboardUrl)
  } catch (error) {
    console.error('Google OAuth error:', error)
    return NextResponse.redirect(new URL('/login?error=oauth_failed', request.url))
  }
}
