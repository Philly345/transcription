import { NextRequest, NextResponse } from 'next/server'
import { generateText } from 'ai'
import { google } from '@ai-sdk/google'

const ASSEMBLYAI_API_KEY = 'bc57f2d5b98d4271a3edb82d84e83dda'
const GEMINI_API_KEY = 'AIzaSyArajy9zhyYWCnBYs5kcSIaIyL87D652_g'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    const settingsStr = formData.get('settings') as string
    
    if (!file) {
      return NextResponse.json(
        { message: 'No file provided' },
        { status: 400 }
      )
    }

    console.log('Processing file:', file.name, 'Size:', file.size)

    const settings = settingsStr ? JSON.parse(settingsStr) : {}
    
    // Convert file to buffer
    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)
    
    console.log('File converted to buffer, size:', buffer.length)
    
    // Upload file to AssemblyAI
    const uploadResponse = await fetch('https://api.assemblyai.com/v2/upload', {
      method: 'POST',
      headers: {
        'authorization': ASSEMBLYAI_API_KEY,
        'content-type': 'application/octet-stream',
      },
      body: buffer,
    })
    
    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text()
      console.error('AssemblyAI upload failed:', errorText)
      throw new Error(`Failed to upload file to AssemblyAI: ${uploadResponse.status}`)
    }
    
    const uploadResult = await uploadResponse.json()
    console.log('File uploaded to AssemblyAI:', uploadResult.upload_url)
    
    // Create transcription request
    const transcriptRequest = {
      audio_url: uploadResult.upload_url,
      language_code: settings.language || 'en',
      speaker_labels: settings.speakerIdentification || false,
      auto_highlights: true,
      sentiment_analysis: true,
      entity_detection: true,
      content_safety: settings.filterProfanity || false,
      auto_chapters: true,
      punctuate: settings.autoPunctuation !== false,
      format_text: true,
    }
    
    console.log('Submitting transcription request:', transcriptRequest)
    
    // Submit transcription job
    const transcriptResponse = await fetch('https://api.assemblyai.com/v2/transcript', {
      method: 'POST',
      headers: {
        'authorization': ASSEMBLYAI_API_KEY,
        'content-type': 'application/json',
      },
      body: JSON.stringify(transcriptRequest),
    })
    
    if (!transcriptResponse.ok) {
      const errorText = await transcriptResponse.text()
      console.error('AssemblyAI transcription submission failed:', errorText)
      throw new Error(`Failed to submit transcription job: ${transcriptResponse.status}`)
    }
    
    const transcriptJob = await transcriptResponse.json()
    const transcriptId = transcriptJob.id
    console.log('Transcription job submitted:', transcriptId)
    
    // Poll for completion
    let transcript
    let attempts = 0
    const maxAttempts = 60 // 5 minutes max
    
    while (attempts < maxAttempts) {
      console.log(`Polling attempt ${attempts + 1}/${maxAttempts}`)
      
      const statusResponse = await fetch(`https://api.assemblyai.com/v2/transcript/${transcriptId}`, {
        headers: {
          'authorization': ASSEMBLYAI_API_KEY,
        },
      })
      
      if (!statusResponse.ok) {
        console.error('Failed to check transcription status:', statusResponse.status)
        throw new Error('Failed to check transcription status')
      }
      
      transcript = await statusResponse.json()
      console.log('Transcription status:', transcript.status)
      
      if (transcript.status === 'completed') {
        console.log('Transcription completed successfully')
        break
      } else if (transcript.status === 'error') {
        console.error('Transcription failed with error:', transcript.error)
        throw new Error('Transcription failed: ' + transcript.error)
      }
      
      // Wait 5 seconds before next poll
      await new Promise(resolve => setTimeout(resolve, 5000))
      attempts++
    }
    
    if (!transcript || transcript.status !== 'completed') {
      throw new Error('Transcription timed out')
    }

    console.log('Generating summary and topic with Gemini')

    // Generate summary and topic using Gemini
    const gemini = google('gemini-1.5-flash', {
      apiKey: GEMINI_API_KEY,
    })

    const { text: summary } = await generateText({
      model: gemini,
      prompt: `Summarize the following transcript in 2-3 sentences: ${transcript.text}`,
    })

    const { text: topic } = await generateText({
      model: gemini,
      prompt: `What is the main topic of this transcript? Respond with just the topic name: ${transcript.text}`,
    })

    // Extract speakers
    let speakers: string[] = []
    if (settings.speakerIdentification && transcript.utterances) {
      const speakerSet = new Set()
      transcript.utterances.forEach((utterance: any) => {
        speakerSet.add(`Speaker ${utterance.speaker}`)
      })
      speakers = Array.from(speakerSet) as string[]
    }

    // Process timestamps
    let timestamps: Array<{ text: string; start: number; end: number }> = []
    if (settings.includeTimestamps && transcript.words) {
      timestamps = transcript.words.map((word: any) => ({
        text: word.text,
        start: word.start / 1000, // Convert to seconds
        end: word.end / 1000
      }))
    }

    const result = {
      transcript: transcript.text,
      summary,
      topic,
      speakers,
      timestamps,
      language: transcript.language_code,
      duration: transcript.audio_duration,
      confidence: transcript.confidence,
      settings
    }

    console.log('Transcription completed successfully')
    return NextResponse.json(result)
  } catch (error) {
    console.error('Transcription error:', error)
    return NextResponse.json(
      { 
        message: 'Transcription failed', 
        error: error instanceof Error ? error.message : 'Unknown error',
        details: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    )
  }
}
