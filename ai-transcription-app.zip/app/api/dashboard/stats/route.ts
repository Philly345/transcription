import { NextRequest, NextResponse } from 'next/server'

// Mock data - in a real app, this would come from a database
const mockStats = {
  totalTranscriptions: 24,
  minutesProcessed: 180,
  storageUsed: 450, // MB
  storageLimit: 1000, // MB
  recentFiles: [
    {
      id: '1',
      name: 'Meeting Recording.mp3',
      status: 'completed',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      duration: 3600 // 1 hour in seconds
    },
    {
      id: '2',
      name: 'Interview Session.mp4',
      status: 'processing',
      createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
    },
    {
      id: '3',
      name: 'Podcast Episode.wav',
      status: 'completed',
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      duration: 2700 // 45 minutes in seconds
    },
    {
      id: '4',
      name: 'Lecture Recording.m4a',
      status: 'failed',
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
    },
    {
      id: '5',
      name: 'Conference Call.mp3',
      status: 'completed',
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 1 week ago
      duration: 1800 // 30 minutes in seconds
    }
  ]
}

export async function GET(request: NextRequest) {
  try {
    // In a real app, you would:
    // 1. Verify JWT token
    // 2. Get user ID from token
    // 3. Query database for user's stats
    // 4. Return actual data

    return NextResponse.json(mockStats)
  } catch (error) {
    console.error('Dashboard stats error:', error)
    return NextResponse.json(
      { message: 'Failed to fetch dashboard stats' },
      { status: 500 }
    )
  }
}
