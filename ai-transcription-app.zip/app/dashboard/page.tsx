'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { FileAudio, Clock, CheckCircle, AlertCircle, Upload, BarChart3, HardDrive, Activity, Info } from 'lucide-react'
import { useAuth } from '@/components/auth-provider'
import Link from 'next/link'
import { useToast } from '@/hooks/use-toast'
import { useRouter } from 'next/navigation'

interface DashboardStats {
  totalTranscriptions: number
  minutesProcessed: number
  storageUsed: number
  storageLimit: number
  recentFiles: Array<{
    id: string
    name: string
    status: 'processing' | 'completed' | 'failed'
    createdAt: string
    duration?: number
  }>
}

export default function DashboardPage() {
  const { user, login } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalTranscriptions: 0,
    minutesProcessed: 0,
    storageUsed: 0,
    storageLimit: 1000, // 1GB in MB
    recentFiles: []
  })
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    // Handle Google OAuth redirect
    const urlParams = new URLSearchParams(window.location.search)
    const authSuccess = urlParams.get('auth')
    const token = urlParams.get('token')
    const userParam = urlParams.get('user')
    
    if (authSuccess === 'success' && token && userParam) {
      try {
        const userData = JSON.parse(Buffer.from(userParam, 'base64').toString())
        login(userData, token)
        
        // Clean up URL
        window.history.replaceState({}, document.title, '/dashboard')
        
        toast({
          title: 'Welcome!',
          description: 'Successfully signed in with Google'
        })
      } catch (error) {
        console.error('Error processing Google auth:', error)
      }
    }
  }, [login, toast])

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch('/api/dashboard/stats')
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const storagePercentage = (stats.storageUsed / stats.storageLimit) * 100

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processing':
        return <Clock className="h-4 w-4 text-yellow-500" />
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <FileAudio className="h-4 w-4" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'processing':
        return <Badge variant="secondary" className="text-yellow-600 bg-yellow-100 dark:bg-yellow-900">Processing</Badge>
      case 'completed':
        return <Badge variant="secondary" className="text-green-600 bg-green-100 dark:bg-green-900">Completed</Badge>
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Welcome{user ? ` back, ${user.name}` : ' to TranscribeAI'}!</h1>
          <p className="text-muted-foreground mt-2">
            {user 
              ? "Here's an overview of your transcription activity"
              : "Try our AI-powered transcription service - no account required"
            }
          </p>
        </div>
        <Link href="/upload">
          <Button className="glow-button">
            <Upload className="h-4 w-4 mr-2" />
            Upload File
          </Button>
        </Link>
      </div>

      {!user && (
        <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Info className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900 dark:text-blue-100">Demo Mode</p>
                <p className="text-sm text-blue-700 dark:text-blue-200">
                  You're using TranscribeAI without an account. Create one to save your transcriptions and access advanced features.
                </p>
              </div>
              <div className="ml-auto space-x-2">
                <Button variant="outline" size="sm" onClick={() => router.push('/signup')}>
                  Sign Up
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transcriptions</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalTranscriptions}</div>
            <p className="text-xs text-muted-foreground">
              Files processed successfully
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Minutes Processed</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.minutesProcessed}</div>
            <p className="text-xs text-muted-foreground">
              Total audio/video duration
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Storage Used</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.storageUsed}MB</div>
            <p className="text-xs text-muted-foreground">
              of {stats.storageLimit}MB available
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Files</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.recentFiles.filter(f => f.status === 'processing').length}
            </div>
            <p className="text-xs text-muted-foreground">
              Currently processing
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Storage Usage */}
      <Card>
        <CardHeader>
          <CardTitle>Storage Usage</CardTitle>
          <CardDescription>
            Monitor your storage consumption and upgrade when needed
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Used: {stats.storageUsed}MB</span>
              <span>Available: {stats.storageLimit - stats.storageUsed}MB</span>
            </div>
            <Progress value={storagePercentage} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {storagePercentage.toFixed(1)}% of your storage limit used
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Files</CardTitle>
          <CardDescription>
            Your latest transcription activity
          </CardDescription>
        </CardHeader>
        <CardContent>
          {stats.recentFiles.length === 0 ? (
            <div className="text-center py-8">
              <FileAudio className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No files yet</h3>
              <p className="text-muted-foreground mb-4">
                Upload your first audio or video file to get started
              </p>
              <Link href="/upload">
                <Button>Upload File</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {stats.recentFiles.map((file) => (
                <div key={file.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(file.status)}
                    <div>
                      <p className="font-medium">{file.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(file.createdAt).toLocaleDateString()} • 
                        {file.duration ? ` ${Math.round(file.duration / 60)} min` : ' Processing...'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusBadge(file.status)}
                    {file.status === 'completed' && (
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
